<?php

class ClienteConjuge extends AppModel 
{
    static $table_name = 'cliente_conjuge';
}