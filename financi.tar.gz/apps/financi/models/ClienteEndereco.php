<?php

class ClienteEndereco extends AppModel 
{
    static $table_name = 'cliente_endereco';
}