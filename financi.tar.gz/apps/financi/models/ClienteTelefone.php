<?php 

class ClienteTelefone extends AppModel 
{
    static $table_name = 'cliente_telefone';

}