<?php 

class CorretorEmail extends AppModel 
{
    static $table_name = 'corretor_email';

}