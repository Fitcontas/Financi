<?php 

class ClienteEmail extends AppModel 
{
    static $table_name = 'cliente_email';

}