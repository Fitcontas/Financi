<?php

class CorretorEndereco extends AppModel 
{
    static $table_name = 'corretor_endereco';
}