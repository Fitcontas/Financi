<?php 

class CorretorTelefone extends AppModel 
{
    static $table_name = 'corretor_telefone';

}